//
//  DateEntension.swift
//  JournalCloudKit
//
//  Created by David Boyd on 5/10/21.
//

import Foundation

extension Date {
    
    func formatToString() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        
        return formatter.string(from: self)
    }
}

