//
//  EntryError.swift
//  JournalCloudKit
//
//  Created by David Boyd on 5/10/21.
//

import Foundation

enum EntryError: LocalizedError {
    case ckError(Error)
    case couldNotUnwrap
    
    var errorDescription: String? {
        
        switch self{
        
        case .ckError(let error):
            return "Error: \(error.localizedDescription) -> \(error)"
        case .couldNotUnwrap:
            return "Unable to unwrap Entry, which is not entry."
        }
    }
}
